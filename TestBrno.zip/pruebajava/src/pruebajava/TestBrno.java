package pruebajava;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;

import org.jsoup.Jsoup;

public class TestBrno extends JFrame implements ActionListener {

    public static final String TMP_FILE = "TestBrno3.txt";
    
	// Form
	public JPanel jpanel = (JPanel) this.getContentPane();
	public JButton boton1;
	public JTextField jtextfield = new JTextField();
	public static String cadena = "";
	public static JLabel errors;
	public static JLabel longestWord;
	public static JLabel mostCommonLetter;
	public static JLabel wordsFrecuency;
	public static DefaultStyledDocument doc = new DefaultStyledDocument();
	public JTextPane pane = new JTextPane(doc);
	public JScrollPane jsp = new JScrollPane(pane);
	

	// Convert html to text
	public static String html2text(String html) {
		return Jsoup.parse(html).text();
	}

	// Read a txt and convert to String
	public static String readFile(String file) throws IOException {

		BufferedReader reader = new BufferedReader(new FileReader(file));
		String line = null;
		StringBuilder stringBuilder = new StringBuilder();
		String ls = System.getProperty("line.separator");

		try {
			while ((line = reader.readLine()) != null) {
				stringBuilder.append(line);
				stringBuilder.append(ls);
			}

			return stringBuilder.toString();
		} finally {
			reader.close();
		}
	}

	// Find the longest word
	public static String LongestWord(String a) {
    
        String[] word = a.split(" ");
        String rts = " ";
        
        for(int i=0;i<word.length;i++){
            if(word[i].length() > rts.length())
                rts = word[i];
        }
        
        return rts;
    }

	// Get max character in the String
	public static char getMax(String word) {
		if (word == null || word.isEmpty()) {
			throw new IllegalArgumentException("input word must have non-empty value.");
		}
		char maxchar = ' ';
		int maxcnt = 0;

		int[] charcnt = new int[Character.MAX_VALUE + 1];
		for (int i = word.length() - 1; i >= 0; i--) {

			char ch = word.charAt(i);
			if (ch == ' ') {
			} else {
				// increment this character's cnt and compare it to our max.
				if (++charcnt[ch] >= maxcnt) {
					maxcnt = charcnt[ch];
					maxchar = ch;
				}
			}
		}
		return maxchar;
	}

	
	public static Map<String, Integer> getWordsFrecuency(String text){
	    
	    Map<String, Integer> map = new HashMap<>();
	    String[] words = text.split(" ");
	    
	    for (String w : words) {
	        Integer n = map.get(w);
	        
	        if(n == null)
	            n = 1;
	        else
                n++;
	        
	        map.put(w, n);
	    }
	    
	    return map;
	}
	
	public static void setWordsFrecuency(Map<String, Integer> map){
	    
	    String text = "";	    

	    for(String word : map.keySet()){
            text = text + "Word: " + word + " (" + map.get(word) + ")\n";
        }
        try {
            doc.insertString(0, text, null);
        } catch (BadLocationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

	public TestBrno() {

		//container properties

		jpanel.setLayout(null);
		jpanel.setBackground(Color.lightGray);

		//Control properties
		
		JLabel label = new JLabel("Insert a secure webpage (https)");
		label.setBounds(25, 20, 300, 30);
		
		jtextfield.setBounds(new Rectangle(25, 50, 250, 21));
		jtextfield.setText("");
		jtextfield.setEditable(true);

		boton1 = new JButton("Send");
		boton1.setBounds(300, 50, 70, 30);
		add(boton1);
		boton1.addActionListener(this);
		
		errors = new JLabel();
		errors.setForeground(Color.RED);
		errors.setBounds(25, 80, 400, 30);

		longestWord = new JLabel("Longest word: ");
		longestWord.setBounds(25, 130, 300, 30);
		mostCommonLetter = new JLabel("Most common letter: ");
		mostCommonLetter.setBounds(25, 160, 300, 30);
		wordsFrecuency = new JLabel("Words Frecuency");
		wordsFrecuency.setBounds(25, 190, 300, 30);
		pane.setBounds(25, 220, 300, 200);
		
		jsp.setBounds(25, 220, 300, 200);
		jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		
		// add controls to the container

		jpanel.add(label, null);
		jpanel.add(jtextfield, null);
		jpanel.add(boton1, null);
		jpanel.add(errors, null);
		jpanel.add(longestWord, null);
		jpanel.add(mostCommonLetter, null);
		jpanel.add(wordsFrecuency, null);
		jpanel.add(jsp, null);

		// form properties
		setSize(600, 500);
		setTitle("TestBrno");
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}

	public static void construir() throws IOException {
		
	    String chain = null;
	    String finalContents = "";
	    
	    if (!cadena.equals("")) {

	        if(!cadena.contains("http:")){
	        
    	        if(!cadena.contains("https://"))
    	            chain = "https://" + cadena;
    	        else
    	            chain = cadena.substring(cadena.indexOf("www"), cadena.length());
    			try{
    			    URL url = new URL(chain);
    			    BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
    			    String inputLine;
    			    
    			    while ((inputLine = reader.readLine()) != null) {
    			        finalContents += "\n" + inputLine.replace("<br", "\n<br");
    			    }
    			
    			//createFolder();
    			
    			BufferedWriter writer = new BufferedWriter(new FileWriter(TMP_FILE));
    			writer.write(finalContents);
    			writer.close();
    
    			String texto = html2text(readFile(TMP_FILE));
    			
                longestWord.setText("Longest word: \t\t" + LongestWord(texto));
                mostCommonLetter.setText("Most common letter: \t" + getMax(texto));
                setWordsFrecuency(getWordsFrecuency(texto));
                
                deleteFolder();
                
    			}catch(MalformedURLException e){
                    errors.setText("Error getting webpage text. Secure url needed (https)");
                }catch(IOException e){
                    errors.setText("Error getting webpage text. Secure url needed (https)");
                }
    		}
	        else{
	            errors.setText("Secure url needed (https)");
	        }
	    }    
	    else{
	        errors.setText("Insert secure URL");
	    }

	}

	private static void deleteFolder(){
	    
	    File folder = new File(TMP_FILE);
	        
	    if(folder.exists())
	        folder.delete();
	}
	
	public static void main(String[] args) throws IOException {

		new TestBrno();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == boton1) {
			cadena = jtextfield.getText();
			try {
				construir();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
}

