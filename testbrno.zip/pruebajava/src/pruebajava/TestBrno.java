package pruebajava;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import org.jsoup.Jsoup;

public class TestBrno extends JFrame implements ActionListener {

	// Form
	JPanel jpanel = (JPanel) this.getContentPane();
	JButton boton1;
	public static String cadena = "";
	JTextField jtextfield = new JTextField();

	// Convert html to text
	public static String html2text(String html) {
		return Jsoup.parse(html).text();
	}

	// Read a txt and convert to String
	public static String readFile(String file) throws IOException {

		BufferedReader reader = new BufferedReader(new FileReader(file));
		String line = null;
		StringBuilder stringBuilder = new StringBuilder();
		String ls = System.getProperty("line.separator");

		try {
			while ((line = reader.readLine()) != null) {
				stringBuilder.append(line);
				stringBuilder.append(ls);
			}

			return stringBuilder.toString();
		} finally {
			reader.close();
		}
	}

	// Find the longest word
	public static String LongestWord(String a) {
		int lw = 0;
		int use;
		String lon = "";
		while (!(a.isEmpty())) {
			a = a.trim();
			use = a.indexOf(" ");
			if (use < 0) {
				break;
			}
			String cut = a.substring(0, use);
			if (cut.length() > lw) {
				lon = cut;
			}
			lw = lon.length();
			a = a.substring(use + 1); // cut the word instead of doing harmful
										// replacement
		}
		return lon;
	}

	// Get max character in the String
	public static char getMax(String word) {
		if (word == null || word.isEmpty()) {
			throw new IllegalArgumentException("input word must have non-empty value.");
		}
		char maxchar = ' ';
		int maxcnt = 0;
		// if you are confident that your input will be only ascii, then this
		// array can be size 128.
		int[] charcnt = new int[Character.MAX_VALUE + 1];
		for (int i = word.length() - 1; i >= 0; i--) {

			char ch = word.charAt(i);
			if (ch == ' ') {
			} else {
				// increment this character's cnt and compare it to our max.
				if (++charcnt[ch] >= maxcnt) {
					maxcnt = charcnt[ch];
					maxchar = ch;
				}
			}
		}
		return maxchar;
	}

	public static void getCount(String text) {
		String example = text;
		// String[] array = new String[example.length()];

		for (int i = 97; i < 123; i++)

		{
			int mostFrequent = 0;

			for (int j = 0; j < example.length(); j++) {
				if (example.charAt(j) == i) {
					++mostFrequent;
				}

			}

			System.out.println((char) i + " is showing " + mostFrequent + " times ");

		}
	}

	public TestBrno() {

		//container properties

		jpanel.setLayout(null);
		jpanel.setBackground(Color.lightGray);

		//Control properties

		jtextfield.setBounds(new Rectangle(25, 15, 250, 21));
		jtextfield.setText("");
		jtextfield.setEditable(true);
		jtextfield.setHorizontalAlignment(JTextField.LEFT);

		boton1 = new JButton("Send");
		boton1.setBounds(300, 250, 100, 30);
		add(boton1);
		boton1.addActionListener(this);

		// add controls to the container

		jpanel.add(jtextfield, null);
		jpanel.add(boton1, null);

		// form properties
		setSize(800, 400);
		setTitle("TestBrno");
		setVisible(true);

	}

	public static void construir() throws IOException {
		if (cadena == null) {
		} else {
			String chain = "https://" + cadena;
			URL url = new URL(chain);
			BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
			String inputLine;
			String finalContents = "";
			while ((inputLine = reader.readLine()) != null) {
				finalContents += "\n" + inputLine.replace("<br", "\n<br");
			}
			BufferedWriter writer = new BufferedWriter(new FileWriter("C:/Users/Eduardo/Desktop/TestBrno3.txt"));
			writer.write(finalContents);
			writer.close();

			String texto = html2text(readFile("C:/Users/Eduardo/Desktop/TestBrno3.txt"));
			System.out.println("The longest word is: " + LongestWord(texto));
			System.out.println("The letter most used is: " + getMax(texto));
			System.out.println("Every letter is showed as the list below");
			getCount(texto);
		}

	}

	public static void main(String[] args) throws IOException {

		new TestBrno();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == boton1) {
			cadena = jtextfield.getText();
			try {
				construir();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
}

