package pruebajava;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestBrnoTestJunit {


		@Test
		public void testgetMaxJunit() {
			char result=TestBrno.getMax("atila");
			assertEquals('a',result);
		}
		@Test
		public void testLongestWord(){
			String result=TestBrno.LongestWord("Executed once, before the start of all tests. It is used to perform time intensive activities , for example, to connect to a database. Methods marked with this annotation need to be defined as static to work with JUnit.");
			assertEquals("activities",result);
		}
		@Test
		public void testhtml2text(){
			String result=TestBrno.html2text("<HTML><p>La casa de Maria</p></HTML>");
			assertEquals("La casa de Maria",result);
		}



}
